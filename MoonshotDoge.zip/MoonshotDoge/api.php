<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    // Get top 5 scores
    try {
        $stmt = $pdo->prepare("SELECT player_name, score FROM high_scores ORDER BY score DESC LIMIT 5");
        $stmt->execute();
        $scores = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'scores' => $scores]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} elseif ($method === 'POST') {
    // Save new high score
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['name']) || !isset($input['score'])) {
        echo json_encode(['success' => false, 'error' => 'Missing name or score']);
        exit;
    }
    
    $name = trim($input['name']);
    $score = (int)$input['score'];
    
    // Validate and sanitize player name
    if (empty($name) || $score < 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid name or score']);
        exit;
    }
    
    // Allow only safe characters: letters, numbers, spaces, and basic punctuation
    if (!preg_match('/^[a-zA-Z0-9\s\-_\.]+$/', $name)) {
        echo json_encode(['success' => false, 'error' => 'Name contains invalid characters. Please use only letters, numbers, spaces, hyphens, underscores, and periods.']);
        exit;
    }
    
    // Limit name length
    if (strlen($name) > 20) {
        echo json_encode(['success' => false, 'error' => 'Name too long. Maximum 20 characters allowed.']);
        exit;
    }
    
    try {
        // Start transaction for proper leaderboard management
        $pdo->beginTransaction();
        
        // Get current top 5 scores
        $stmt = $pdo->prepare("SELECT id, player_name, score FROM high_scores ORDER BY score DESC LIMIT 5");
        $stmt->execute();
        $currentTop5 = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Find the correct position for the new score
        $insertPosition = -1;
        for ($i = 0; $i < count($currentTop5); $i++) {
            if ($score > $currentTop5[$i]['score']) {
                $insertPosition = $i;
                break;
            }
        }
        
        // If we have less than 5 scores and new score didn't beat any, add it to the end
        if ($insertPosition === -1 && count($currentTop5) < 5) {
            $insertPosition = count($currentTop5);
        }
        
        // Only proceed if the score deserves to be in top 5
        if ($insertPosition !== -1) {
            // If we have 5 scores and inserting at any position, remove the last one
            if (count($currentTop5) === 5) {
                $lastScore = $currentTop5[4];
                $stmt = $pdo->prepare("DELETE FROM high_scores WHERE id = ?");
                $stmt->execute([$lastScore['id']]);
            }
            
            // Insert the new score
            $stmt = $pdo->prepare("INSERT INTO high_scores (player_name, score) VALUES (?, ?)");
            $stmt->execute([$name, $score]);
            
            // Clean up - ensure we keep only top 5 scores (safety measure)
            $pdo->exec("DELETE FROM high_scores WHERE id NOT IN (
                SELECT id FROM (
                    SELECT id FROM high_scores ORDER BY score DESC LIMIT 5
                ) AS top_scores
            )");
        }
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Score saved successfully']);
    } catch (PDOException $e) {
        $pdo->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
}
?>