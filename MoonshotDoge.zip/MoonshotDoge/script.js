// Game variables
let canvas, ctx;
let gameState = 'start'; // 'start', 'playing', 'gameOver', 'highScore'
let score = 0;
let gameSpeed = 2;
let pipes = [];
let particles = [];
let topScores = [];

// Doge character
let doge = {
    x: 100,
    y: 0,
    width: 60,
    height: 60,
    velocity: 0,
    gravity: 0.5,
    jumpForce: -10,
    image: null
};

// Background scrolling
let bgX = 0;

// Game elements
const PIPE_WIDTH = 80;
const PIPE_GAP = 200;
const PIPE_SPACING = 300;

// Initialize game
function init() {
    canvas = document.getElementById('gameCanvas');
    ctx = canvas.getContext('2d');
    
    // Set canvas size to full screen
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Load doge image
    doge.image = new Image();
    doge.image.src = 'assets/doge-character.png';
    
    // Set initial doge position
    doge.y = canvas.height / 2;
    
    // Event listeners
    canvas.addEventListener('click', handleInput);
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space') {
            e.preventDefault();
            handleInput();
        }
    });
    
    // UI event listeners
    document.getElementById('start-btn').addEventListener('click', startGame);
    document.getElementById('play-again-btn').addEventListener('click', startGame);
    document.getElementById('save-score-btn').addEventListener('click', saveHighScore);
    
    // Enter key for name input
    document.getElementById('player-name').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            saveHighScore();
        }
    });
    
    // Load leaderboard
    loadLeaderboard();
    
    // Start game loop
    gameLoop();
}

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    // Adjust doge position if canvas resized during game
    if (gameState === 'playing' && doge.y > canvas.height - doge.height) {
        doge.y = canvas.height - doge.height;
    }
}

function handleInput() {
    if (gameState === 'playing') {
        doge.velocity = doge.jumpForce;
        
        // Add particle effect
        for (let i = 0; i < 5; i++) {
            particles.push({
                x: doge.x + doge.width/2,
                y: doge.y + doge.height,
                vx: (Math.random() - 0.5) * 4,
                vy: Math.random() * 3 + 2,
                life: 30,
                maxLife: 30
            });
        }
    }
}

function startGame() {
    gameState = 'playing';
    score = 0;
    gameSpeed = 2;
    pipes = [];
    particles = [];
    
    doge.y = canvas.height / 2;
    doge.velocity = 0;
    
    // Update score display to show 0
    updateScoreDisplay();
    
    // Hide all screens
    document.getElementById('start-screen').classList.add('hidden');
    document.getElementById('game-over-screen').classList.add('hidden');
    document.getElementById('high-score-screen').classList.add('hidden');
    
    // Generate initial pipes
    generatePipe();
}

function generatePipe() {
    const minHeight = 100;
    const maxHeight = canvas.height - PIPE_GAP - minHeight;
    const topHeight = Math.random() * (maxHeight - minHeight) + minHeight;
    
    pipes.push({
        x: canvas.width,
        topHeight: topHeight,
        bottomY: topHeight + PIPE_GAP,
        bottomHeight: canvas.height - (topHeight + PIPE_GAP),
        passed: false
    });
}

function updateGame() {
    if (gameState !== 'playing') return;
    
    // Update doge physics
    doge.velocity += doge.gravity;
    doge.y += doge.velocity;
    
    // Keep doge in bounds
    if (doge.y < 0) {
        doge.y = 0;
        doge.velocity = 0;
    }
    if (doge.y > canvas.height - doge.height) {
        gameOver();
        return;
    }
    
    // Update pipes
    for (let i = pipes.length - 1; i >= 0; i--) {
        pipes[i].x -= gameSpeed;
        
        // Check if doge passed pipe
        if (!pipes[i].passed && pipes[i].x + PIPE_WIDTH < doge.x) {
            pipes[i].passed = true;
            score++;
            updateScoreDisplay();
            
            // Increase game speed gradually
            if (score % 5 === 0) {
                gameSpeed += 0.2;
            }
        }
        
        // Remove off-screen pipes
        if (pipes[i].x + PIPE_WIDTH < 0) {
            pipes.splice(i, 1);
        }
        
        // Check collision
        if (checkCollision(pipes[i])) {
            gameOver();
            return;
        }
    }
    
    // Generate new pipes
    if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - PIPE_SPACING) {
        generatePipe();
    }
    
    // Update particles
    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].x += particles[i].vx;
        particles[i].y += particles[i].vy;
        particles[i].life--;
        
        if (particles[i].life <= 0) {
            particles.splice(i, 1);
        }
    }
    
    // Update background scroll
    bgX -= gameSpeed * 0.5;
    if (bgX <= -canvas.width) {
        bgX = 0;
    }
}

function checkCollision(pipe) {
    // Simple rectangle collision detection
    const dogeLeft = doge.x;
    const dogeRight = doge.x + doge.width;
    const dogeTop = doge.y;
    const dogeBottom = doge.y + doge.height;
    
    const pipeLeft = pipe.x;
    const pipeRight = pipe.x + PIPE_WIDTH;
    
    // Check if doge is horizontally aligned with pipe
    if (dogeRight > pipeLeft && dogeLeft < pipeRight) {
        // Check collision with top pipe
        if (dogeTop < pipe.topHeight) {
            return true;
        }
        // Check collision with bottom pipe
        if (dogeBottom > pipe.bottomY) {
            return true;
        }
    }
    
    return false;
}

function gameOver() {
    gameState = 'gameOver';
    
    // Check if it's a high score
    if (isHighScore(score)) {
        showHighScoreScreen();
    } else {
        showGameOverScreen();
    }
}

function isHighScore(currentScore) {
    if (topScores.length < 5) return true;
    return currentScore > topScores[topScores.length - 1].score;
}

function showGameOverScreen() {
    document.getElementById('final-score-value').textContent = score;
    document.getElementById('game-over-screen').classList.remove('hidden');
}

function showHighScoreScreen() {
    gameState = 'highScore';
    document.getElementById('new-score-value').textContent = score;
    document.getElementById('high-score-screen').classList.remove('hidden');
    document.getElementById('player-name').focus();
}

function updateScoreDisplay() {
    document.getElementById('score-value').textContent = score;
}

function drawGame() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw background stars
    drawStars();
    
    if (gameState === 'playing') {
        // Draw pipes
        pipes.forEach(pipe => drawPipe(pipe));
        
        // Draw particles
        particles.forEach(particle => drawParticle(particle));
        
        // Draw doge
        drawDoge();
    }
}

function drawStars() {
    ctx.fillStyle = 'white';
    for (let i = 0; i < 100; i++) {
        const x = (i * 50 + bgX) % canvas.width;
        const y = (i * 37) % canvas.height;
        const size = Math.random() * 2;
        ctx.fillRect(x, y, size, size);
    }
}

function drawPipe(pipe) {
    ctx.fillStyle = '#4a4a4a';
    ctx.strokeStyle = '#2a2a2a';
    ctx.lineWidth = 3;
    
    // Top pipe
    ctx.fillRect(pipe.x, 0, PIPE_WIDTH, pipe.topHeight);
    ctx.strokeRect(pipe.x, 0, PIPE_WIDTH, pipe.topHeight);
    
    // Bottom pipe
    ctx.fillRect(pipe.x, pipe.bottomY, PIPE_WIDTH, pipe.bottomHeight);
    ctx.strokeRect(pipe.x, pipe.bottomY, PIPE_WIDTH, pipe.bottomHeight);
    
    // Pipe caps
    ctx.fillStyle = '#666';
    ctx.fillRect(pipe.x - 5, pipe.topHeight - 20, PIPE_WIDTH + 10, 20);
    ctx.fillRect(pipe.x - 5, pipe.bottomY, PIPE_WIDTH + 10, 20);
}

function drawDoge() {
    ctx.save();
    
    // Rotation based on velocity
    const rotation = Math.min(Math.max(doge.velocity * 0.05, -0.5), 0.5);
    ctx.translate(doge.x + doge.width/2, doge.y + doge.height/2);
    ctx.rotate(rotation);
    
    if (doge.image.complete) {
        ctx.drawImage(doge.image, -doge.width/2, -doge.height/2, doge.width, doge.height);
    } else {
        // Fallback if image not loaded
        ctx.fillStyle = '#ff6b35';
        ctx.fillRect(-doge.width/2, -doge.height/2, doge.width, doge.height);
    }
    
    ctx.restore();
}

function drawParticle(particle) {
    const alpha = particle.life / particle.maxLife;
    ctx.fillStyle = `rgba(255, 165, 0, ${alpha})`;
    ctx.fillRect(particle.x - 2, particle.y - 2, 4, 4);
}

function loadLeaderboard() {
    fetch('api.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                topScores = data.scores;
                displayLeaderboard();
            }
        })
        .catch(error => {
            console.error('Error loading leaderboard:', error);
            document.getElementById('scores-list').innerHTML = '<div class="loading">Failed to load</div>';
        });
}

function displayLeaderboard() {
    const scoresList = document.getElementById('scores-list');
    
    if (topScores.length === 0) {
        scoresList.innerHTML = '<div class="loading">No scores yet</div>';
        return;
    }
    
    scoresList.innerHTML = '';
    topScores.forEach((scoreData, index) => {
        const scoreItem = document.createElement('div');
        scoreItem.className = 'score-item';
        
        // Create spans with safe text content (prevents XSS)
        const nameSpan = document.createElement('span');
        nameSpan.textContent = `${index + 1}. ${scoreData.player_name}`;
        
        const scoreSpan = document.createElement('span');
        scoreSpan.textContent = scoreData.score;
        
        scoreItem.appendChild(nameSpan);
        scoreItem.appendChild(scoreSpan);
        scoresList.appendChild(scoreItem);
    });
}

function saveHighScore() {
    const name = document.getElementById('player-name').value.trim();
    
    if (!name) {
        alert('Please enter your name!');
        return;
    }
    
    const data = {
        name: name,
        score: score
    };
    
    fetch('api.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Reload leaderboard
            loadLeaderboard();
            // Clear name input
            document.getElementById('player-name').value = '';
            // Start new game
            startGame();
        } else {
            alert('Error saving score: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error saving score:', error);
        alert('Error saving score. Please try again.');
    });
}

function gameLoop() {
    updateGame();
    drawGame();
    requestAnimationFrame(gameLoop);
}

// Start the game when page loads
document.addEventListener('DOMContentLoaded', init);