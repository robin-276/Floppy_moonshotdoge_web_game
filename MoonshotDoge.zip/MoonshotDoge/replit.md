# Space Doge - Flappy Bird Game

## Overview

Space Doge is a browser-based Flappy Bird-style game featuring a space-themed doge character navigating through obstacles in space. The game provides full-screen responsive gameplay that works on both mobile and desktop devices, with a live scoring system and persistent leaderboard. Players control a doge character with realistic physics through pipe obstacles, earning points for each successful passage. The game features anonymous gameplay with optional name entry for high scores, creating an accessible gaming experience without requiring user accounts.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend uses a pure HTML5/CSS3/Vanilla JavaScript architecture without frameworks, prioritizing simplicity and performance. The game renders on an HTML5 canvas element for smooth animations and responsive gameplay. The UI consists of overlay screens for start, game over, and leaderboard displays positioned absolutely over the canvas. CSS3 handles responsive styling with viewport-based units and media queries to ensure consistent experience across devices. JavaScript manages the game loop, physics calculations, collision detection, and state management through a simple state machine pattern.

### Backend Architecture
The backend follows a minimal PHP-based REST API approach with a single `api.php` file handling all server-side operations. Database configuration is separated into `config.php` for connection management. The API provides endpoints for retrieving top scores and submitting new scores, with simple GET/POST request handling. This lightweight approach reduces complexity while providing necessary persistence functionality.

### Data Storage
PostgreSQL serves as the primary database for storing leaderboard data. The database schema focuses on simplicity with a scores table containing player names, scores, and timestamps. This choice provides ACID compliance and reliable data persistence for the competitive leaderboard feature while being straightforward to manage and query.

### Game Engine Design
The game implements a custom 2D game engine using HTML5 Canvas API with a traditional game loop pattern. Physics simulation includes gravity, jump mechanics, and collision detection calculated per frame. The rendering system handles sprite drawing, background scrolling, and particle effects. Game state management uses a simple state machine with clear transitions between start, playing, game over, and high score states.

### Asset Management
Static assets including character sprites and background images are served directly from the filesystem. The architecture assumes a simple web server setup without complex asset bundling or CDN requirements. Image loading is handled asynchronously to prevent blocking the game initialization.

## External Dependencies

### Database
- **PostgreSQL**: Primary database for persistent leaderboard storage, chosen for its reliability and SQL compliance
- **PHP PDO**: Database abstraction layer for secure database interactions and prepared statements

### Web Technologies
- **HTML5 Canvas API**: Core rendering engine for 2D game graphics and animations
- **CSS3**: Styling and responsive design features including transforms and animations
- **Vanilla JavaScript**: Game logic implementation without external frameworks

### Asset Dependencies
- **Doge character sprite**: PNG image asset for the main game character
- **Space background**: JPG background image for the game environment

### Browser APIs
- **Canvas 2D Context**: For game rendering and graphics manipulation
- **Keyboard/Mouse Events**: For player input handling across desktop and mobile devices
- **Fetch API**: For client-server communication with the leaderboard backend

The architecture emphasizes simplicity and direct browser API usage over complex frameworks, making the codebase easily maintainable and performant across different devices and browsers.